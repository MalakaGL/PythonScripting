__title__ = 'twentiment'
__version__ = '0.1.0'
__build__ = 0x001000
__author__ = 'Pascal Hartig'
__license__ = 'Apache 2'
__copyright__ = 'Copyright 2012 Pascal Hartig'
